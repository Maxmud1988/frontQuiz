import React from "react";
import {
  Box,
  List,
  ListItemIcon,
  ListItemText,
  Divider,
  ListItemButton,
} from "@mui/material";
import { Link as RouterLink } from "react-router-dom";
import { useAppSelector } from "../../../hooks/redux";
import { selectUser } from "../../../features/users/userSlice";
import { publicLinks, userLinks, adminLinks } from "./menuLinks";

interface SiteMenuProps {
  isMobile?: boolean;
}

const SiteMenu: React.FC<SiteMenuProps> = ({ isMobile = false }) => {
  const user = useAppSelector(selectUser);

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: isMobile ? "column" : "row",
        alignItems: "flex-start",
      }}
    >
      <List
        sx={{ display: "flex", flexDirection: isMobile ? "column" : "row" }}
      >
        {publicLinks.map((link) => (
          <ListItemButton
            key={link.label}
            component={RouterLink}
            to={link.path}
          >
            {isMobile && <ListItemIcon>{link.icon}</ListItemIcon>}
            <ListItemText primary={link.label} />
          </ListItemButton>
        ))}
        {isMobile && <Divider orientation="horizontal" flexItem />}
        {user &&
          userLinks.map((link) => (
            <ListItemButton
              key={link.label}
              component={RouterLink}
              to={link.path}
            >
              {isMobile && <ListItemIcon>{link.icon}</ListItemIcon>}
              <ListItemText primary={link.label} />
            </ListItemButton>
          ))}
        {isMobile && <Divider orientation="horizontal" flexItem />}
        {user &&
          user.role === "admin" &&
          adminLinks.map((link) => (
            <ListItemButton
              key={link.label}
              component={RouterLink}
              to={link.path}
            >
              {isMobile && <ListItemIcon>{link.icon}</ListItemIcon>}
              <ListItemText primary={link.label} />
            </ListItemButton>
          ))}
      </List>
    </Box>
  );
};

export default SiteMenu;
