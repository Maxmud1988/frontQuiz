// src/pages/admin/AdminDashboard.tsx
import React from "react";
import { Box, Typography } from "@mui/material";

const AdminDashboard: React.FC = () => {
  return (
    <Box>
      <Typography variant="h3" component="h1" gutterBottom>
        Панель администратора
      </Typography>
      <Typography variant="body1">
        Здесь вы можете управлять пользователями, викторинами и другими
        настройками приложения.
      </Typography>
    </Box>
  );
};

export default AdminDashboard;
