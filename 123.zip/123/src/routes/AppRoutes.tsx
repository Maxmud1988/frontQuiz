// src/routes/AppRoutes.tsx
import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import MainLayout from "../layouts/MainLayout";
import AdminLayout from "../layouts/AdminLayout";
import ProtectedRoutes from "./ProtectedRoutes";
import HomePage from "../pages/HomePage";
import LoginPage from "../pages/LoginPage";
import UnauthorizedPage from "../pages/UnauthorizedPage";
import AdminDashboard from "../pages/Admin";

const AppRoutes: React.FC = () => {
  return (
    <Routes>
      {/* Публичные маршруты */}
      <Route element={<MainLayout />}>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/unauthorized" element={<UnauthorizedPage />} />
      </Route>

      {/* Защищенные маршруты для пользователей и администраторов */}
      <Route element={<ProtectedRoutes allowedRoles={["user", "admin"]} />}>
        <Route element={<MainLayout />}>
          {/* Здесь можно добавить маршруты для личного кабинета пользователя */}
          <Route
            path="/user/*"
            element={
              <div>
                Пользовательский кабинет (страницы для создания/редактирования
                викторин)
              </div>
            }
          />
        </Route>
      </Route>

      {/* Защищенные маршруты для администраторов */}
      {/* <Route element={<ProtectedRoutes allowedRoles={["admin"]} />}> */}
      <Route path="/admin" element={<AdminLayout />}>
        <Route index element={<AdminDashboard />} />
        {/* Здесь можно добавить другие админские маршруты */}
      </Route>
      {/* </Route> */}

      {/* Если маршрут не найден – редирект на главную */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

export default AppRoutes;
