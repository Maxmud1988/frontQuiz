// services/axiosInstance.ts
import axios, { AxiosError, InternalAxiosRequestConfig } from "axios";
import { refreshTokenThunk, logoutThunk } from "../features/auth/authSice";
import { tokenService } from "../services/tokenService";
// Импорт типов, если нужно
import type { AppStore } from "../store"; // Тип корневого состояния

let isRefreshing = false;
let failedQueue: Array<{
  resolve: (value?: unknown) => void;
  reject: (reason?: unknown) => void;
}> = [];

const processQueue = (error: Error | null, token: string | null) => {
  failedQueue.forEach((prom) => {
    if (error) {
      prom.reject(error);
    } else {
      prom.resolve(token);
    }
  });
  failedQueue = [];
};

// Создаём базовый инстанс без интерсепторов
const $api = axios.create({
  baseURL: "http://localhost:3000",
  withCredentials: true,
});

// Функция инициализации, принимающая store
export function initApi(store: AppStore) {
  // Request interceptor
  $api.interceptors.request.use(
    (config: InternalAxiosRequestConfig) => {
      const token = tokenService.getAccessToken();
      if (token && config.headers) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    },
    (error) => Promise.reject(error)
  );

  // Response interceptor
  $api.interceptors.response.use(
    (response) => response,
    async (error: AxiosError) => {
      const originalRequest = error.config as InternalAxiosRequestConfig & {
        _retry?: boolean;
      };

      if (error.response?.status === 401 && !originalRequest._retry) {
        if (isRefreshing) {
          // Уже есть запрос на обновление, помещаемся в очередь
          return new Promise((resolve, reject) => {
            failedQueue.push({ resolve, reject });
          })
            .then((token) => {
              if (token && originalRequest.headers) {
                originalRequest.headers.Authorization = `Bearer ${token}`;
              }
              return axios(originalRequest);
            })
            .catch((err) => Promise.reject(err));
        }

        originalRequest._retry = true;
        isRefreshing = true;

        try {
          // Вызываем refresh через thunk
          const refreshResult = await store.dispatch(refreshTokenThunk());
          if (refreshTokenThunk.fulfilled.match(refreshResult)) {
            const newAccessToken = refreshResult.payload.accessToken;
            processQueue(null, newAccessToken);
            if (originalRequest.headers) {
              originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;
            }
            return axios(originalRequest);
          } else {
            // Если рефреш не прошёл, логаутим
            processQueue(new Error("Refresh failed"), null);
            store.dispatch(logoutThunk());
            return Promise.reject(error);
          }
        } catch (err) {
          processQueue(err as Error, null);
          store.dispatch(logoutThunk());
          return Promise.reject(err);
        } finally {
          isRefreshing = false;
        }
      }

      return Promise.reject(error);
    }
  );
}

// Экспортируем сам инстанс
export default $api;
