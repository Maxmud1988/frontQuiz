import { Outlet } from "react-router-dom";
import { Container, Box, Typography } from "@mui/material";
import Header from "../components/layout/Header";

const Layout = () => {
  return (
    <Box sx={{ display: "flex", flexDirection: "column", minHeight: "100vh" }}>
      <Header />
      <main style={{ flex: 1 }}>
        <Container component="main" sx={{ flexGrow: 1, py: 3 }}>
          <Outlet />
        </Container>
      </main>
      <footer style={{ marginTop: "auto" }}>
        <Box sx={{ textAlign: "center", py: 2, backgroundColor: "#f5f5f5" }}>
          <Typography variant="body2">
            &copy; {new Date().getFullYear()} Quiz App. Все права защищены.
          </Typography>
        </Box>
      </footer>
    </Box>
  );
};

export default Layout;
