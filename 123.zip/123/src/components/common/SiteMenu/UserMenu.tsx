import React from "react";
import {
  ListItemIcon,
  ListItemText,
  ListItemButton,
  Avatar,
  Menu,
  MenuItem,
  Box,
  IconButton,
  Tooltip,
} from "@mui/material";
import { Link as RouterLink } from "react-router-dom";
import { useAppSelector } from "../../../hooks/redux";
import { selectUser } from "../../../features/users/userSlice";
import { guestLinks, userLinks } from "./menuLinks";

interface UserMenuProps {
  isMobile: boolean;
}

const UserMenu: React.FC<UserMenuProps> = ({ isMobile }) => {
  const user = useAppSelector(selectUser);
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);

  const handleMenu = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <Box sx={{ display: isMobile ? "block" : "flex", alignItems: "center" }}>
      {!user ? (
        guestLinks.map((link) => (
          <ListItemButton
            key={link.label}
            component={RouterLink}
            to={link.path}
          >
            {isMobile && <ListItemIcon>{link.icon}</ListItemIcon>}
            <ListItemText primary={link.label} />
          </ListItemButton>
        ))
      ) : (
        <>
          <ListItemButton onClick={handleMenu}>
            {isMobile && (
              <ListItemIcon>
                <Avatar>{user.username.charAt(0).toUpperCase()}</Avatar>
              </ListItemIcon>
            )}
            <ListItemText primary={user.username} />
          </ListItemButton>
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleClose}
          >
            {userLinks.map((link) => (
              <MenuItem
                key={link.label}
                component={RouterLink}
                to={link.path}
                onClick={handleClose}
              >
                {isMobile ? (
                  <>
                    <ListItemIcon>{link.icon}</ListItemIcon>
                    <ListItemText primary={link.label} />
                  </>
                ) : (
                  <Tooltip title={link.label}>
                    <IconButton>{link.icon}</IconButton>
                  </Tooltip>
                )}
              </MenuItem>
            ))}
          </Menu>
        </>
      )}
    </Box>
  );
};

export default UserMenu;
