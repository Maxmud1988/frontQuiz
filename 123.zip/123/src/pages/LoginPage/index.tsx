import React from "react";
import {
  Box,
  Typography,
  TextField,
  Button,
  Alert,
  CircularProgress,
  Checkbox,
  FormControlLabel,
  Paper,
  Grid,
} from "@mui/material";
import { useForm, SubmitHandler } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { Link as RouterLink, useNavigate } from "react-router-dom";
import {
  signinThunk,
  selectAuthLoading,
  selectAuthError,
} from "../../features/auth/authSice";
import GoogleIcon from "@mui/icons-material/Google";
import { useAppDispatch, useAppSelector } from "../../hooks/redux";
import AuthService from "../../features/auth/services";
import { Container, styled } from "@mui/system";

// Типы формы
interface LoginFormInputs {
  email: string;
  password: string;
  remember: boolean;
}

// Схема валидации
const schema = yup
  .object({
    email: yup
      .string()
      .email("Введите корректный email")
      .required("Email обязателен"),
    password: yup
      .string()
      .min(6, "Пароль должен быть не менее 6 символов")
      .required("Пароль обязателен"),
    remember: yup.boolean().required(),
  })
  .required();

// Стилизованный компонент для формы
const FormPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  borderRadius: theme.spacing(2),
  boxShadow: "0px 8px 30px rgba(0, 0, 0, 0.2)",
  maxWidth: "350px",
  width: "100%",
  background: "rgba(255, 255, 255, 0.95)",
}));

const LoginPage: React.FC = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const loading = useAppSelector(selectAuthLoading);
  const error = useAppSelector(selectAuthError);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormInputs>({
    resolver: yupResolver(schema),
    defaultValues: { remember: false },
  });

  // Обработка входа по email/паролю
  const onSubmit: SubmitHandler<LoginFormInputs> = async (data) => {
    try {
      await dispatch(signinThunk(data)).unwrap();
      navigate("/"); // Перенаправление по успешному логину
    } catch (err) {
      console.error("Ошибка входа:", err);
    }
  };

  // Обработка входа через Google
  const handleGoogleSignIn = () => {
    try {
      AuthService.googleSignin();
    } catch (err) {
      console.error("Ошибка входа через Google:", err);
    }
  };

  return (
    <Container>
      <FormPaper elevation={5} sx={{ padding: "1rem" }}>
        <Typography
          component="h1"
          variant="h4"
          align="center"
          sx={{ fontWeight: "bold", mb: 3, color: "#333" }}
        >
          Вход в систему
        </Typography>
        <Box
          component="form"
          onSubmit={handleSubmit(onSubmit)}
          noValidate
          sx={{ mt: 1 }}
        >
          <TextField
            fullWidth
            label="Email"
            autoComplete="email"
            autoFocus
            size="small"
            {...register("email")}
            error={!!errors.email}
            helperText={errors.email?.message}
            sx={{ mb: 2 }}
          />
          <TextField
            size="small"
            fullWidth
            label="Пароль"
            type="password"
            autoComplete="current-password"
            {...register("password")}
            error={!!errors.password}
            helperText={errors.password?.message}
            sx={{ mb: 2 }}
          />
          <FormControlLabel
            control={<Checkbox color="primary" {...register("remember")} />}
            label="Запомнить меня"
            sx={{ mb: 2, color: "#555" }}
          />
          {error && (
            <Alert severity="error" sx={{ mt: 2, mb: 2 }}>
              {error}
            </Alert>
          )}
          <Button
            type="submit"
            fullWidth
            variant="contained"
            disabled={loading}
            sx={{
              mt: 2,
              mb: 2,
              py: 1.5,
              background: "linear-gradient(45deg, #6a11cb, #2575fc)",
              color: "white",
              "&:hover": {
                background: "linear-gradient(45deg, #2575fc, #6a11cb)",
              },
              transition: "background 0.5s ease",
            }}
          >
            {loading ? <CircularProgress size={24} color="inherit" /> : "Войти"}
          </Button>
          <Button
            fullWidth
            variant="outlined"
            startIcon={<GoogleIcon />}
            onClick={handleGoogleSignIn}
            disabled={loading}
            sx={{
              mt: 1,
              mb: 2,
              py: 1.5,
              borderColor: "#DB4437",
              color: "#DB4437",
              "&:hover": {
                borderColor: "#DB4437",
                backgroundColor: "rgba(219, 68, 55, 0.04)",
              },
              transition: "all 0.3s ease",
            }}
          >
            Войти через Google
          </Button>
          <Grid container justifyContent="space-between">
            <Grid item>
              <Button
                component={RouterLink}
                to="/forgot-password"
                size="small"
                sx={{ color: "#6a11cb", textTransform: "none" }}
              >
                Забыли пароль?
              </Button>
            </Grid>
            <Grid item>
              <Button
                component={RouterLink}
                to="/signup"
                size="small"
                sx={{ color: "#6a11cb", textTransform: "none" }}
              >
                Зарегистрироваться
              </Button>
            </Grid>
          </Grid>
        </Box>
      </FormPaper>
    </Container>
  );
};

export default LoginPage;
