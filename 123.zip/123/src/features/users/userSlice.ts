// src/store/Slices/user/index.ts
import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import UserService, {
  IUser,
  IUserListResponse,
  IChangePasswordData,
  ICreateUserData,
} from "./services";
import { RootState } from "../../store";

interface UserState {
  user: IUser | null;
  usersList: IUserListResponse | null;
  loading: boolean;
  error: string | null;
}

const initialState: UserState = {
  user: null,
  usersList: null,
  loading: false,
  error: null,
};

// Получаем информацию о текущем пользователе (/users/me)
export const fetchCurrentUserThunk = createAsyncThunk(
  "user/fetchCurrentUser",
  async (_, { rejectWithValue }) => {
    try {
      const user = await UserService.getMe();
      return user;
    } catch (error: unknown) {
      const err = error as { response?: { data?: { message?: string } } };
      return rejectWithValue(
        err.response?.data?.message || "Failed to fetch user data"
      );
    }
  }
);

// Обновление информации о текущем пользователе (/users/me, PATCH)
export const updateCurrentUserThunk = createAsyncThunk(
  "user/updateCurrentUser",
  async (data: Partial<IUser>, { rejectWithValue }) => {
    try {
      const updatedUser = await UserService.updateMe(data);
      return updatedUser;
    } catch (error: unknown) {
      const err = error as { response?: { data?: { message?: string } } };
      return rejectWithValue(
        err.response?.data?.message || "Failed to update user"
      );
    }
  }
);

// Получение списка всех пользователей (/users/all)
export const fetchAllUsersThunk = createAsyncThunk(
  "user/fetchAllUsers",
  async (
    params: { page: number; limit: number; query?: string },
    { rejectWithValue }
  ) => {
    try {
      const res = await UserService.getAll(
        params.page,
        params.limit,
        params.query
      );
      return res;
    } catch (error: unknown) {
      const err = error as { response?: { data?: { message?: string } } };
      return rejectWithValue(
        err.response?.data?.message || "Failed to fetch users list"
      );
    }
  }
);

// Изменение статуса блокировки пользователя (/users/{id}/block)
export const updateUserStatusThunk = createAsyncThunk(
  "user/updateUserStatus",
  async (
    params: { userId: string; isBlocked: boolean },
    { rejectWithValue }
  ) => {
    try {
      const updatedUser = await UserService.updateUserStatus(
        params.userId,
        params.isBlocked
      );
      return updatedUser;
    } catch (error: unknown) {
      const err = error as { response?: { data?: { message?: string } } };
      return rejectWithValue(
        err.response?.data?.message || "Failed to update user status"
      );
    }
  }
);

// Изменение роли пользователя (/users/{id}/role)
export const updateUserRoleThunk = createAsyncThunk(
  "user/updateUserRole",
  async (params: { userId: string; role: string }, { rejectWithValue }) => {
    try {
      const updatedUser = await UserService.updateUserRole(
        params.userId,
        params.role
      );
      return updatedUser;
    } catch (error: unknown) {
      const err = error as { response?: { data?: { message?: string } } };
      return rejectWithValue(
        err.response?.data?.message || "Failed to update user role"
      );
    }
  }
);

// Создание пользователя (/users/create)
export const createUserThunk = createAsyncThunk(
  "user/createUser",
  async (data: ICreateUserData, { rejectWithValue }) => {
    try {
      const newUser = await UserService.create(data);
      return newUser;
    } catch (error: unknown) {
      const err = error as { response?: { data?: { message?: string } } };
      return rejectWithValue(
        err.response?.data?.message || "Failed to create user"
      );
    }
  }
);

// Смена пароля (/users/change-password)
export const changePasswordThunk = createAsyncThunk(
  "user/changePassword",
  async (data: IChangePasswordData, { rejectWithValue }) => {
    try {
      await UserService.changePassword(data);
      return true;
    } catch (error: unknown) {
      const err = error as { response?: { data?: { message?: string } } };
      return rejectWithValue(
        err.response?.data?.message || "Failed to change password"
      );
    }
  }
);

// Удаление пользователя (/users/{id})
export const removeUserThunk = createAsyncThunk(
  "user/removeUser",
  async (userId: string, { rejectWithValue }) => {
    try {
      await UserService.remove(userId);
      return userId;
    } catch (error: unknown) {
      const err = error as { response?: { data?: { message?: string } } };
      return rejectWithValue(
        err.response?.data?.message || "Failed to remove user"
      );
    }
  }
);

const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    clearUserData: (state) => {
      state.user = null;
      state.usersList = null;
      state.loading = false;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    // fetchCurrentUserThunk
    builder.addCase(fetchCurrentUserThunk.pending, (state) => {
      state.loading = true;
      state.error = null;
    });
    builder.addCase(
      fetchCurrentUserThunk.fulfilled,
      (state, action: PayloadAction<IUser>) => {
        state.loading = false;
        state.user = action.payload;
        state.error = null;
      }
    );
    builder.addCase(fetchCurrentUserThunk.rejected, (state, action) => {
      state.loading = false;
      state.user = null;
      state.error = action.payload as string;
    });

    // updateCurrentUserThunk
    builder.addCase(updateCurrentUserThunk.pending, (state) => {
      state.loading = true;
      state.error = null;
    });
    builder.addCase(
      updateCurrentUserThunk.fulfilled,
      (state, action: PayloadAction<IUser>) => {
        state.loading = false;
        state.user = action.payload;
        state.error = null;
      }
    );
    builder.addCase(updateCurrentUserThunk.rejected, (state, action) => {
      state.loading = false;
      state.error = action.payload as string;
    });

    // fetchAllUsersThunk
    builder.addCase(fetchAllUsersThunk.pending, (state) => {
      state.loading = true;
      state.error = null;
    });
    builder.addCase(
      fetchAllUsersThunk.fulfilled,
      (state, action: PayloadAction<IUserListResponse>) => {
        state.loading = false;
        state.usersList = action.payload;
        state.error = null;
      }
    );
    builder.addCase(fetchAllUsersThunk.rejected, (state, action) => {
      state.loading = false;
      state.error = action.payload as string;
    });

    // updateUserStatusThunk
    builder.addCase(updateUserStatusThunk.pending, (state) => {
      state.loading = true;
      state.error = null;
    });
    builder.addCase(
      updateUserStatusThunk.fulfilled,
      (state, action: PayloadAction<IUser>) => {
        state.loading = false;
        if (state.user && state.user.id === action.payload.id) {
          state.user = action.payload;
        }
        if (state.usersList) {
          state.usersList.users = state.usersList.users.map((u) =>
            u.id === action.payload.id ? action.payload : u
          );
        }
        state.error = null;
      }
    );
    builder.addCase(updateUserStatusThunk.rejected, (state, action) => {
      state.loading = false;
      state.error = action.payload as string;
    });

    // updateUserRoleThunk
    builder.addCase(updateUserRoleThunk.pending, (state) => {
      state.loading = true;
      state.error = null;
    });
    builder.addCase(
      updateUserRoleThunk.fulfilled,
      (state, action: PayloadAction<IUser>) => {
        state.loading = false;
        if (state.user && state.user.id === action.payload.id) {
          state.user = action.payload;
        }
        if (state.usersList) {
          state.usersList.users = state.usersList.users.map((u) =>
            u.id === action.payload.id ? action.payload : u
          );
        }
        state.error = null;
      }
    );
    builder.addCase(updateUserRoleThunk.rejected, (state, action) => {
      state.loading = false;
      state.error = action.payload as string;
    });

    // createUserThunk
    builder.addCase(createUserThunk.pending, (state) => {
      state.loading = true;
      state.error = null;
    });
    builder.addCase(
      createUserThunk.fulfilled,
      (state, action: PayloadAction<IUser>) => {
        state.loading = false;
        if (state.usersList) {
          state.usersList.users.push(action.payload);
          state.usersList.totalUsers += 1;
          state.usersList.totalPages = Math.ceil(
            state.usersList.totalUsers / 10
          );
        }
        state.error = null;
      }
    );
    builder.addCase(createUserThunk.rejected, (state, action) => {
      state.loading = false;
      state.error = action.payload as string;
    });

    // changePasswordThunk
    builder.addCase(changePasswordThunk.pending, (state) => {
      state.loading = true;
      state.error = null;
    });
    builder.addCase(changePasswordThunk.fulfilled, (state) => {
      state.loading = false;
      state.error = null;
    });
    builder.addCase(changePasswordThunk.rejected, (state, action) => {
      state.loading = false;
      state.error = action.payload as string;
    });

    // removeUserThunk
    builder.addCase(removeUserThunk.pending, (state) => {
      state.loading = true;
      state.error = null;
    });
    builder.addCase(
      removeUserThunk.fulfilled,
      (state, action: PayloadAction<string>) => {
        state.loading = false;
        if (state.user && state.user.id === action.payload) {
          state.user = null;
        }
        if (state.usersList) {
          state.usersList.users = state.usersList.users.filter(
            (u) => u.id !== action.payload
          );
          state.usersList.totalUsers -= 1;
          state.usersList.totalPages = Math.ceil(
            state.usersList.totalUsers / 10
          );
        }
        state.error = null;
      }
    );
    builder.addCase(removeUserThunk.rejected, (state, action) => {
      state.loading = false;
      state.error = action.payload as string;
    });
  },
});

export const { clearUserData } = userSlice.actions;
export default userSlice.reducer;

// Селекторы
export const selectUser = (state: RootState) => state.user.user;
export const selectUsersList = (state: RootState) => state.user.usersList;
export const selectUserLoading = (state: RootState) => state.user.loading;
export const selectUserError = (state: RootState) => state.user.error;
