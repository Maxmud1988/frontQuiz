import React from "react";
import LoginIcon from "@mui/icons-material/Login";
import PersonAddIcon from "@mui/icons-material/PersonAdd";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import SettingsIcon from "@mui/icons-material/Settings";
import ExitToAppIcon from "@mui/icons-material/ExitToApp";
import HomeIcon from "@mui/icons-material/Home";
import QuizIcon from "@mui/icons-material/Quiz";
import AdminPanelSettingsIcon from "@mui/icons-material/AdminPanelSettings";
import DashboardIcon from "@mui/icons-material/Dashboard";
import AssignmentIcon from "@mui/icons-material/Assignment";

export interface MenuLink {
  label: string;
  path: string;
  icon?: React.ReactNode;
}

export const guestLinks: MenuLink[] = [
  { label: "Sign In", path: "/login", icon: <LoginIcon /> },
  { label: "Sign Up", path: "/signup", icon: <PersonAddIcon /> },
];

export const userLinks: MenuLink[] = [
  { label: "Profile", path: "/profile", icon: <AccountCircleIcon /> },
  { label: "Settings", path: "/settings", icon: <SettingsIcon /> },
  { label: "Logout", path: "/logout", icon: <ExitToAppIcon /> },
  { label: "Dashboard", path: "/user/dashboard", icon: <DashboardIcon /> },
  { label: "My Quizzes", path: "/user/quizzes", icon: <AssignmentIcon /> },
];

export const publicLinks: MenuLink[] = [
  { label: "Home", path: "/", icon: <HomeIcon /> },
  { label: "Quizzes", path: "/quizzes", icon: <QuizIcon /> },
  { label: "Quizzes", path: "/quizzes", icon: <QuizIcon /> },
  { label: "Quizzes", path: "/quizzes", icon: <QuizIcon /> },
  { label: "Quizzes", path: "/quizzes", icon: <QuizIcon /> },
  { label: "Quizzes", path: "/quizzes", icon: <QuizIcon /> },
];

export const adminLinks: MenuLink[] = [
  { label: "Admin", path: "/admin", icon: <AdminPanelSettingsIcon /> },
];
