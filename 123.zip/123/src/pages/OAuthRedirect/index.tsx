// src/pages/OAuthRedirect.tsx
import React, { useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { CircularProgress, Container, Typography } from "@mui/material";

import { setGoogleAuth } from "../../features/auth/authSice";
import { useAppDispatch } from "../../hooks/redux";

const OAuthRedirect: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  useEffect(() => {
    // Извлекаем access_token из query-параметров
    const params = new URLSearchParams(location.search);
    const accessToken = params.get("access_token");

    if (accessToken) {
      // Устанавливаем токен через Redux (например, с помощью setGoogleAuth)
      dispatch(setGoogleAuth({ accessToken }));
      navigate("/"); // Перенаправляем пользователя на главную или в личный кабинет
    } else {
      // Если токен отсутствует, можно показать сообщение об ошибке или перенаправить на страницу логина
      navigate("/login");
    }
  }, [location.search, dispatch, navigate]);

  return (
    <Container sx={{ textAlign: "center", mt: 4 }}>
      <CircularProgress />
      <Typography variant="h6" sx={{ mt: 2 }}>
        Обработка входа...
      </Typography>
    </Container>
  );
};

export default OAuthRedirect;
