// src/services/tokenService/index.ts
export const tokenService = {
  getAccessToken(): string | null {
    return localStorage.getItem("accessToken");
  },
  setAccessToken(token: string): void {
    localStorage.setItem("accessToken", token);
  },
  clearAccessToken(): void {
    localStorage.removeItem("accessToken");
  },
};
