// src/App.tsx
import React, { useEffect } from "react";
import { useAppDispatch, useAppSelector } from "./hooks/redux";
import { selectAccessToken } from "./features/auth/authSice";
import { fetchCurrentUserThunk } from "./features/users/userSlice";
import AppRoutes from "./routes/AppRoutes";

const App: React.FC = () => {
  const dispatch = useAppDispatch();

  // Используем селекторы, чтобы смотреть текущее состояние авторизации
  // const isAuth = useAppSelector(selectIsAuth);
  const accessToken = useAppSelector(selectAccessToken);

  useEffect(() => {
    // Если в localStorage (или в Redux) у нас есть accessToken,
    // значит пользователь "как бы" авторизован
    if (accessToken) {
      // Тогда пытаемся запросить /users/me,
      // чтобы убедиться, что токен не просрочен
      dispatch(fetchCurrentUserThunk());
    }
    // Если токена нет, мы этого не делаем
  }, [dispatch, accessToken]);
  return (
    <div className="App">
      <AppRoutes />
    </div>
  );
};

export default App;
