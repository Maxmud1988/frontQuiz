import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import AuthService from "./services";
import { RootState } from "../../store";
import { clearUserData } from "../users/userSlice";

interface AuthState {
  accessToken: string | null;
  isAuth: boolean;
  loading: boolean;
  error: string | null;
}

const initialState: AuthState = {
  accessToken: localStorage.getItem("accessToken") || null,
  isAuth: !!localStorage.getItem("accessToken"),
  loading: false,
  error: null,
};

// Регистрация
export const signupThunk = createAsyncThunk(
  "auth/signup",
  async (
    data: { email: string; password: string; username: string },
    { rejectWithValue }
  ) => {
    try {
      const response = await AuthService.signup(data);
      return response;
    } catch (e: unknown) {
      const errorMessage = e instanceof Error ? e.message : "Signup failed";
      return rejectWithValue(errorMessage);
    }
  }
);

// Логин по email/паролю
export const signinThunk = createAsyncThunk(
  "auth/signin",
  async (data: { email: string; password: string }, { rejectWithValue }) => {
    try {
      const response = await AuthService.signin(data);
      return response;
    } catch (e: unknown) {
      const errorMessage = e instanceof Error ? e.message : "SignIn failed";
      return rejectWithValue(errorMessage);
    }
  }
);

// Выход из системы
export const logoutThunk = createAsyncThunk(
  "auth/logout",
  async (_, { dispatch, rejectWithValue }) => {
    try {
      await AuthService.logout();
      dispatch(clearUserData());
      return true;
    } catch (e: unknown) {
      dispatch(clearUserData());
      const errorMessage = e instanceof Error ? e.message : "Logout failed";
      return rejectWithValue(errorMessage);
    }
  }
);

// Рефреш токена
export const refreshTokenThunk = createAsyncThunk(
  "auth/refreshToken",
  async (_, { rejectWithValue }) => {
    try {
      const response = await AuthService.refreshToken();
      return response;
    } catch (e: unknown) {
      const errorMessage =
        e instanceof Error ? e.message : "Refresh token failed";
      return rejectWithValue(errorMessage);
    }
  }
);

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    logout: (state) => {
      state.accessToken = null;
      state.isAuth = false;
      localStorage.removeItem("accessToken");
    },
    setGoogleAuth: (state, action: PayloadAction<{ accessToken: string }>) => {
      state.accessToken = action.payload.accessToken;
      state.isAuth = true;
      localStorage.setItem("accessToken", action.payload.accessToken);
    },
  },
  extraReducers: (builder) => {
    // signup
    builder.addCase(signupThunk.pending, (state) => {
      state.loading = true;
      state.error = null;
    });
    builder.addCase(signupThunk.fulfilled, (state, action) => {
      state.loading = false;
      state.error = null;
      const { accessToken } = action.payload;
      state.accessToken = accessToken;
      state.isAuth = true;
      localStorage.setItem("accessToken", accessToken);
    });
    builder.addCase(signupThunk.rejected, (state, action) => {
      state.loading = false;
      state.error = action.payload as string;
    });

    // signin
    builder.addCase(signinThunk.pending, (state) => {
      state.loading = true;
      state.error = null;
    });
    builder.addCase(signinThunk.fulfilled, (state, action) => {
      state.loading = false;
      state.error = null;
      const { accessToken } = action.payload;
      state.accessToken = accessToken;
      state.isAuth = true;
      localStorage.setItem("accessToken", accessToken);
    });
    builder.addCase(signinThunk.rejected, (state, action) => {
      state.loading = false;
      state.error = action.payload as string;
      state.isAuth = false;
      state.accessToken = null;
    });

    // logout
    builder.addCase(logoutThunk.fulfilled, (state) => {
      state.accessToken = null;
      state.isAuth = false;
      localStorage.removeItem("accessToken");
    });
    builder.addCase(logoutThunk.rejected, (state) => {
      state.accessToken = null;
      state.isAuth = false;
      localStorage.removeItem("accessToken");
    });

    // refresh
    builder.addCase(refreshTokenThunk.fulfilled, (state, action) => {
      const { accessToken } = action.payload;
      state.accessToken = accessToken;
      state.isAuth = true;
      localStorage.setItem("accessToken", accessToken);
    });
    builder.addCase(refreshTokenThunk.rejected, (state) => {
      state.accessToken = null;
      state.isAuth = false;
      localStorage.removeItem("accessToken");
    });
  },
});

export const { logout, setGoogleAuth } = authSlice.actions;
export default authSlice.reducer;

// Селекторы
export const selectIsAuth = (state: RootState) => state.auth.isAuth;
export const selectAccessToken = (state: RootState) => state.auth.accessToken;
export const selectAuthLoading = (state: RootState) => state.auth.loading;
export const selectAuthError = (state: RootState) => state.auth.error;
