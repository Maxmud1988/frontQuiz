const MainMenu = () => {
  return <div>MainMenu</div>;
};

export default MainMenu;
