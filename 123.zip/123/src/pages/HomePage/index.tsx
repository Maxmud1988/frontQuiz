// src/pages/HomePage.tsx
import React from "react";
import { Box, Typography } from "@mui/material";

const HomePage: React.FC = () => {
  return (
    <Box>
      <Typography variant="h3" component="h1" gutterBottom>
        Добро пожаловать в QuizApp!
      </Typography>
      <Typography variant="body1">
        Здесь вы можете проходить викторины или создавать свои собственные.
      </Typography>
    </Box>
  );
};

export default HomePage;
