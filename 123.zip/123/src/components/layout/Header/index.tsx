import { AppBar } from "@mui/material";
import Navigation from "../../../layouts/Navigations";

const Header = () => {
  return (
    <AppBar position="static">
      <Navigation />
    </AppBar>
  );
};

export default Header;
