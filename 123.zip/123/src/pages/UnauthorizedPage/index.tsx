// src/pages/UnauthorizedPage.tsx
import React from "react";
import { Box, Typography } from "@mui/material";

const UnauthorizedPage: React.FC = () => {
  return (
    <Box sx={{ mt: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        Нет доступа
      </Typography>
      <Typography variant="body1">
        У вас недостаточно прав для просмотра этой страницы.
      </Typography>
    </Box>
  );
};

export default UnauthorizedPage;
