// src/services/Auth/userService.ts
import $api from "../../services/axiosInstance";
import { AxiosResponse } from "axios";

export interface IUser {
  id: string;
  email: string;
  username: string;
  role: string;
  isBlocked: boolean;
  lastLogin?: string;
  createdAt?: string;
}

// Интерфейс для ответа при получении списка пользователей
export interface IUserListResponse {
  totalUsers: number;
  currentPage: number;
  totalPages: number;
  users: IUser[];
}

// Данные для смены пароля
export interface IChangePasswordData {
  currentPassword: string;
  newPassword: string;
}

// Данные для создания пользователя (регистрация через админку)
export interface ICreateUserData {
  email: string;
  username: string;
  password: string;
  role?: string; // Если не передано, будет установлена роль по умолчанию на бэкенде
}

export default class UserService {
  // Получение информации о текущем пользователе (/users/me)
  static async getMe(): Promise<IUser> {
    const response: AxiosResponse<IUser> = await $api.get("/users/me");
    return response.data;
  }

  // Обновление информации о текущем пользователе (/users/me, PATCH)
  static async updateMe(data: Partial<IUser>): Promise<IUser> {
    const response: AxiosResponse<IUser> = await $api.patch("/users/me", data);
    return response.data;
  }

  // Создание нового пользователя (админ: POST /users/create)
  static async create(data: ICreateUserData): Promise<IUser> {
    const response: AxiosResponse<IUser> = await $api.post(
      "/users/create",
      data
    );
    return response.data;
  }

  // Смена пароля (/users/change-password, PATCH)
  static async changePassword(data: IChangePasswordData): Promise<void> {
    await $api.patch("/users/change-password", data);
  }

  // Получение списка всех пользователей с пагинацией и поиском (GET /users/all)
  static async getAll(
    page: number,
    limit: number,
    query?: string
  ): Promise<IUserListResponse> {
    const response: AxiosResponse<IUserListResponse> = await $api.get(
      "/users/all",
      {
        params: { page, limit, query },
      }
    );
    return response.data;
  }

  // Изменение роли пользователя (PATCH /users/{id}/role)
  static async updateUserRole(userId: string, role: string): Promise<IUser> {
    const response: AxiosResponse<IUser> = await $api.patch(
      `/users/${userId}/role`,
      { role }
    );
    return response.data;
  }

  // Блокировка/разблокировка пользователя (PATCH /users/{id}/block)
  static async updateUserStatus(
    userId: string,
    isBlocked: boolean
  ): Promise<IUser> {
    const response: AxiosResponse<IUser> = await $api.patch(
      `/users/${userId}/block`,
      { isBlocked }
    );
    return response.data;
  }

  // Удаление пользователя (DELETE /users/{id})
  static async remove(userId: string): Promise<void> {
    await $api.delete(`/users/${userId}`);
  }
}
