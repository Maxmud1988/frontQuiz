import { useState } from "react";

const NavMenu = () => {
  const [open, setOpen] = useState(false);

  const togleDrawer = (newOpen: boolean) => {
    setOpen(newOpen);
  };
  return (
    <div>
      <div className="div"></div>
    </div>
  );
};

export default NavMenu;
u;
