import { AxiosResponse } from "axios";
import $api from "../../services/axiosInstance";

export interface IAuthResponse {
  accessToken: string;
  refreshToken?: string; // Обычно refreshToken возвращается в httpOnly-cookie, но если сервер присылает его в теле, то тут он есть
}

export interface ISignInData {
  email: string;
  password: string;
}

export interface ISignUpData {
  email: string;
  password: string;
  username: string;
}

export default class AuthService {
  static async signup(data: ISignUpData): Promise<IAuthResponse> {
    // POST /auth/signup
    const response: AxiosResponse<IAuthResponse> = await $api.post(
      "/auth/signup",
      data
    );
    return response.data;
  }

  static async signin(data: ISignInData): Promise<IAuthResponse> {
    // POST /auth/signin
    const response: AxiosResponse<IAuthResponse> = await $api.post(
      "/auth/signin",
      data
    );
    return response.data;
  }

  static async logout(): Promise<void> {
    // POST /auth/logout (часто POST или GET - зависит от бекенда)
    await $api.post("/auth/logout");
  }

  static async refreshToken(): Promise<IAuthResponse> {
    // POST /auth/refresh
    const response: AxiosResponse<IAuthResponse> = await $api.post(
      "/auth/refresh"
    );
    return response.data;
  }

  /**
   * Инициализирует процесс входа через Google.
   * При вызове происходит перенаправление браузера на эндпоинт аутентификации Google.
   * После успешного входа бекенд перенаправляет пользователя на фронтенд с access_token в query-параметре.
   */
  static googleSignin(): Promise<IAuthResponse> {
    // Формируем URL для перенаправления (убедитесь, что URL соответствует настройкам вашего бекенда)
    const googleAuthUrl = "http://localhost:3000/auth/google";
    window.location.href = googleAuthUrl;
    // Возвращаем промис, который не резолвится, так как происходит перенаправление
    return new Promise(() => {});
  }
}
