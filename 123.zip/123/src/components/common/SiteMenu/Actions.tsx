// src/components/common/Actions.tsx
import React, { useState } from "react";
import { IconButton, Menu, MenuItem } from "@mui/material";
import Brightness4Icon from "@mui/icons-material/Brightness4";
import Brightness7Icon from "@mui/icons-material/Brightness7";
import TranslateIcon from "@mui/icons-material/Translate";
import { useThemeContext } from "../../../contexts/hooks";

const Actions: React.FC = () => {
  const { toggleTheme, mode } = useThemeContext();
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

  const handleLanguageClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleLanguageClose = () => {
    setAnchorEl(null);
  };

  // Пример списка языков
  const languages = [
    { code: "en", label: "English" },
    { code: "ru", label: "Русский" },
  ];

  return (
    <>
      <IconButton onClick={toggleTheme} color="inherit">
        {mode === "light" ? <Brightness4Icon /> : <Brightness7Icon />}
      </IconButton>
      <IconButton onClick={handleLanguageClick} color="inherit">
        <TranslateIcon />
      </IconButton>
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleLanguageClose}
      >
        {languages.map((lang) => (
          <MenuItem key={lang.code} onClick={handleLanguageClose}>
            {lang.label}
          </MenuItem>
        ))}
      </Menu>
    </>
  );
};

export default Actions;
