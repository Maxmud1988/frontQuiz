// src/routes/ProtectedRoutes.tsx
import React from "react";
import { Navigate, Outlet } from "react-router-dom";
import { useAppSelector } from "../hooks/redux";
import { selectUser } from "../features/users/userSlice";

interface ProtectedRoutesProps {
  allowedRoles: string[];
}

const ProtectedRoutes: React.FC<ProtectedRoutesProps> = ({ allowedRoles }) => {
  const user = useAppSelector(selectUser);

  // Если пользователь не авторизован, перенаправляем на страницу логина
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // Если роль пользователя входит в список разрешенных, отображаем дочерние маршруты
  if (allowedRoles.includes(user.role)) {
    return <Outlet />;
  }

  // Если роль не разрешена, перенаправляем на страницу "Нет доступа"
  return <Navigate to="/unauthorized" replace />;
};

export default ProtectedRoutes;
